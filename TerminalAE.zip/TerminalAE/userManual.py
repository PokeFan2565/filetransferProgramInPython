


def userManual():
	return ''' 
	password = termux
	Command :- 
	admin
	termux --plugin --verion
	termux --plugin --owner
	showdata
	advance command
	'''