
import os
import arrow
'''
dataBasePath =	"/storage/emulated/0/Android/data/termux/database.txt"
firstData = {'dataBasePath' : '/storage/emulated/0/Android/data/termux/database.txt', 'name'	: 'Alok'}


'''

# Defining Function


def writeData(dataBasePath, data):
	with open(dataBasePath, 'w') as f:
		f.write(str(data))

def makeDataBase(dataBasePath, firstData):
	if not os.path.exists(dataBasePath):
		writeData(dataBasePath, firstData)
			
def readData(dataBasePath):
	newDictData =	{}
	if os.path.exists(dataBasePath):
		with open(dataBasePath, 'r') as f:
			readedData =	f.read()
		readedData=	readedData.replace('{', '')
		readedData=	readedData.replace('}', '')
		readedData=	readedData.replace(' ', '')
		readedData=	readedData.replace("'", '')
		readedData=	readedData.split(',')
		for i in readedData:
			i =	i.split(':')
			element1 =	i[0]
			element2 =	i[1]
			newDictData[element1] =	element2
			
	return newDictData
	
def enterNewData(dataBasePath, oldData, newData):
	for key in newData:
		oldData[key] = newData[key]
	writeData(dataBasePath, oldData)
	
	
	
	
	
def showData():
	Path =	"/storage/emulated/0/Android/data/termux/database.txt"
	data = readData(Path)
	for key in data:
		print(f"{arrow.notic(key, 'red')} : {arrow.notic(data[key], 'red')}")
	
	
# Checking Function 






	