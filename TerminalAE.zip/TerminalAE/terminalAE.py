
# Importing Area -->

import os


# Self Created Files
import arrow
import changePath
import help
import admin
import dataBase
import userManual

# Globle Veriables

dataBasePath =	"/storage/emulated/0/Android/data/termux/database.txt"

dataBaseFolder =	"/storage/emulated/0/Android/data/termux/"



exitTheProgram = False


#Coding Area -->


os.chdir('/storage/emulated/0')
os.system('clear')

if not os.path.exists(dataBaseFolder):
	os.chdir('/storage/emulated/0/Android/data/')
	os.system('mkdir termux')
	



while not exitTheProgram:
	data =	dataBase.readData(dataBasePath)
	userCommand =arrow.arrow()
	changePath.changePath(userCommand)
	if userCommand =='help':
		print(help.help())
	elif userCommand == 'cd --help':
		print(help.cdHelp())
	elif userCommand == 'cp --help':
		print(help.cpHelp())
	elif userCommand == 'termux --plugin --version':
		print('Turmux Admin Edition(AE) V.1.0')
	elif userCommand == 'termux --plugin --owner':
		print('Termux Admin Edition(AE) Version v.1.0 \n')
		print('\tCreated By Alok Mistry :\n')
		print('Email :- alokmistry79@gmail.com')
	elif userCommand == 'admin':
		admin.main()
	elif userCommand ==	'showdata':
		dataBase.showData()
	elif userCommand ==	'advance command':
		print(userManual.userManual())
	elif userCommand ==	'exit':
		exitTheProgram =	True
	elif userCommand == "uninstall":
		os.system("sh /data/data/com.termux/files/usr/etc/uninstall/uninstall.sh")
	elif userCommand ==	'termux':
		os.chdir('/data/data/com.termux/files/home')
	elif userCommand ==	'sdcard':
		os.chdir('/storage/emulated/0')
	else:
		if userCommand[0:2] != 'cd':
			if userCommand in data:
				os.chdir(data[userCommand])
			else:
				os.system(userCommand)
					
	

