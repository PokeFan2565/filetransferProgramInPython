rm -f /data/data/com.termux/files/usr/etc/bash.bashrc
cp -f /data/data/com.termux/files/usr/etc/uninstall/bash.bashrc /data/data/com.termux/files/usr/etc
rm -f /data/data/com.termux/files/usr/etc/terminalAE.py
rm -f /data/data/com.termux/files/usr/etc/help.py
rm -f /data/data/com.termux/files/usr/etc/arrow.py
rm -f /data/data/com.termux/files/usr/etc/admin.py
rm -f /data/data/com.termux/files/usr/etc/dataBase.py
rm -f /data/data/com.termux/files/usr/etc/userManual.py
rm -f /data/data/com.termux/files/usr/etc/changePath.py
rm -f /data/data/com.termux/files/usr/etc/bash.bashrc