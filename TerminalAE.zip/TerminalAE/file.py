import os

if not os.path.exists("/data/data/com.termux/files/usr/etc/uninstall"):
	os.mkdir("/data/data/com.termux/files/usr/etc/uninstall")
		