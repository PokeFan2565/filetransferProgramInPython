
# Importing Are


import os
import dataBase
import arrow


def main():
	
	# Veriables
	
	
	dataBasePath =	"/storage/emulated/0/Android/data/termux/database.txt"
	firstData = {'dataBasePath' : '/storage/emulated/0/Android/data/termux/database.txt', 'name'	: 'Alok'}
	gameOver =	False
	dataBaseFolder =	"/storage/emulated/0/Android/data/termux/"
	
	
	# Body
	
	
	if not os.path.exists(dataBaseFolder):
		os.system('mkdir storage/emulated/0/Android/data/termux')
	
	dataBase.makeDataBase(dataBasePath, firstData)
	while not gameOver:
		newData =	{}
		password =	arrow.arrowWithNotic('Enter Your Password : ')
		if password ==	'termux':
			fileName = arrow.arrowWithNotic('Enter Your File Name : ')
			filePath = arrow.arrowWithNotic('Enter File Path : ')
			data =	dataBase.readData(dataBasePath)
			newData[fileName] = filePath
			dataBase.enterNewData(dataBasePath, data, newData)
			print(arrow.notic('Data Updated Sucessfully :\nEnter Any Key To Exit.', 'green'))
			input()
			gameOver =	True
		else:
			gameOver =	True
		

