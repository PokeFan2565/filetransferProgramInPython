import imageEditor
import arrow
import os

def find(type):
	
	
	imageList =	[]
	imageSrc =	[]
	i =	1
	
	
	
	
	path = arrow.arrowWithNotic('Enter Target Path : ')
	
	os.chdir(path)
	list = os.listdir()
	#print(arrow.notic(os.getcwd(), 'green'))
	
	imagePath =	os.getcwd()
	
	for image in list:
		if image.find(type) !=	-1:
			print(f'{i}] {image}')
			imageList.append(image)
			i =	i+1
			
			
	print(arrow.notic('ImageList : ', 'red'))
	for image in imageList:
		imageSrc.append(f'{imagePath}/{image}')
		
		
		
	return imageSrc
	

	
	




# /storage/emulated/0/python/Tools/ImageEditing