

# Importing Are


import os
import arrow


# Veriables
exit =	True



# Function Area


def findImageName(link):
	link =	link.split('/')
	imageName =	link[-1]
	return imageName[0:-4]


def openImageCode(imageLink, saveFolderLink, type):
	imageName =	findImageName(imageLink)
	with open(imageLink, 'rb') as f:
		imageCode =	f.read()
	#print(imageCode)
	with open(f'{saveFolderLink}/{imageName}.{type}', 'wb') as f:
		f.write(imageCode)
	print('File Saved SucessFully : ')
		
		
		
		


	


#Main


# /storage/emulated/0/python/Tools/ImageEditing

# /storage/emulated/0/python/Tools/ImageEditing/Image1.jpg


