

# Importing Are

import os
import arrow
import imageEditor
import fileManager






print(arrow.notic('Selct Any On 1 Or 2 : ', 'red'))

print('1] Enter File Type To Coppy : .jpg / .txt Or Much More : ')
fileType =	input()

print('2] Enter Type To Save File : .jpg / .txt Or Much More : ')
saveType =	input()








demoImage =	fileManager.find(fileType)
folderLink = arrow.arrowWithNotic('Enter Folder Path Where You Want To Save~~~~> ')
for image in demoImage:
	imageEditor.openImageCode(image, folderLink, saveType)
		
		
		
		
		
		
# /storage/emulated/0/WhatsApp/Media/WhatsApp Images
		
# /storage/emulated/0/python/Tools/ImageEditing/imageFromCode
	